"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { ChevronLeft, ChevronRight, Menu, Home } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet"
import TableOfContents from "@/components/table-of-contents"
import { chapters } from "@/lib/ebook-data"

export default function ChapterPage({ params }: { params: { chapter: string } }) {
  const chapterNum = Number.parseInt(params.chapter)
  const chapter = chapters.find((c) => c.id === chapterNum) || chapters[0]
  const nextChapter = chapters.find((c) => c.id === chapterNum + 1)
  const prevChapter = chapters.find((c) => c.id === chapterNum - 1)

  const [pageNum, setPageNum] = useState(1)
  const totalPages = chapter.content.length

  // Reset page number when chapter changes
  useEffect(() => {
    setPageNum(1)
  }, [chapterNum])

  const nextPage = () => {
    if (pageNum < totalPages) {
      setPageNum(pageNum + 1)
    } else if (nextChapter) {
      // Go to next chapter
      window.location.href = `/ebook/${nextChapter.id}`
    }
  }

  const prevPage = () => {
    if (pageNum > 1) {
      setPageNum(pageNum - 1)
    } else if (prevChapter) {
      // Go to previous chapter, last page
      window.location.href = `/ebook/${prevChapter.id}?page=${prevChapter.content.length}`
    }
  }

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col">
      {/* Header */}
      <header className="bg-white border-b border-slate-200 py-4 px-6 flex items-center justify-between">
        <div className="flex items-center gap-4">
          <Link href="/" className="text-slate-600 hover:text-slate-900">
            <Home className="h-5 w-5" />
          </Link>
          <h1 className="text-xl font-semibold text-slate-900 hidden md:block">Master Drawing</h1>
        </div>

        <div className="text-center">
          <h2 className="text-lg font-medium text-slate-800">
            Chapter {chapter.id}: {chapter.title}
          </h2>
          <p className="text-sm text-slate-500">
            Page {pageNum} of {totalPages}
          </p>
        </div>

        <Sheet>
          <SheetTrigger asChild>
            <Button variant="outline" size="icon">
              <Menu className="h-5 w-5" />
              <span className="sr-only">Open table of contents</span>
            </Button>
          </SheetTrigger>
          <SheetContent side="right">
            <TableOfContents currentChapter={chapterNum} />
          </SheetContent>
        </Sheet>
      </header>

      {/* Main content */}
      <main className="flex-1 container mx-auto px-4 py-8 max-w-4xl">
        <div className="bg-white rounded-lg shadow-lg p-8 min-h-[60vh]">
          <div className="prose max-w-none">
            <h2 className="text-2xl font-bold mb-6">{chapter.content[pageNum - 1].title}</h2>
            <div dangerouslySetInnerHTML={{ __html: chapter.content[pageNum - 1].text }} />

            {chapter.content[pageNum - 1].hasExercise && (
              <div className="mt-8 p-4 border border-slate-200 rounded-lg bg-slate-50">
                <h3 className="text-lg font-semibold mb-2">Practice Exercise</h3>
                <p className="mb-4">{chapter.content[pageNum - 1].exerciseText}</p>
                <Button asChild>
                  <Link href={`/canvas?exercise=${chapterNum}-${pageNum}`}>Open Drawing Canvas</Link>
                </Button>
              </div>
            )}
          </div>
        </div>
      </main>

      {/* Navigation */}
      <div className="container mx-auto px-4 py-6 max-w-4xl flex justify-between">
        <Button onClick={prevPage} disabled={pageNum === 1 && !prevChapter} variant="outline">
          <ChevronLeft className="mr-2 h-4 w-4" /> Previous
        </Button>

        <Button onClick={nextPage} disabled={pageNum === totalPages && !nextChapter}>
          Next <ChevronRight className="ml-2 h-4 w-4" />
        </Button>
      </div>
    </div>
  )
}

