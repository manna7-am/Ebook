"use client"

import type React from "react"

import { useState, useRef, useEffect } from "react"
import { useSearchParams } from "next/navigation"
import Link from "next/link"
import { Pencil, Eraser, Save, Trash2, Home, Undo, Redo, ChevronLeft, PanelLeft } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Slider } from "@/components/ui/slider"
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip"
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet"
import { chapters } from "@/lib/ebook-data"

export default function Canvas() {
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const searchParams = useSearchParams()
  const exerciseParam = searchParams.get("exercise")

  const [isDrawing, setIsDrawing] = useState(false)
  const [tool, setTool] = useState("pencil")
  const [color, setColor] = useState("#000000")
  const [lineWidth, setLineWidth] = useState(5)
  const [history, setHistory] = useState<ImageData[]>([])
  const [historyIndex, setHistoryIndex] = useState(-1)

  // Get exercise details if available
  const exerciseInfo = exerciseParam
    ? {
        chapter: Number.parseInt(exerciseParam.split("-")[0]),
        page: Number.parseInt(exerciseParam.split("-")[1]),
      }
    : null

  const exerciseDetails = exerciseInfo
    ? chapters.find((c) => c.id === exerciseInfo.chapter)?.content[exerciseInfo.page - 1]
    : null

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return

    const ctx = canvas.getContext("2d")
    if (!ctx) return

    // Set canvas size
    canvas.width = canvas.offsetWidth
    canvas.height = canvas.offsetHeight

    // Fill with white background
    ctx.fillStyle = "white"
    ctx.fillRect(0, 0, canvas.width, canvas.height)

    // Save initial state
    const initialState = ctx.getImageData(0, 0, canvas.width, canvas.height)
    setHistory([initialState])
    setHistoryIndex(0)
  }, [])

  const startDrawing = (e: React.MouseEvent<HTMLCanvasElement> | React.TouchEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current
    if (!canvas) return

    const ctx = canvas.getContext("2d")
    if (!ctx) return

    setIsDrawing(true)

    // Get coordinates
    let x, y
    if ("touches" in e) {
      const rect = canvas.getBoundingClientRect()
      x = e.touches[0].clientX - rect.left
      y = e.touches[0].clientY - rect.top
    } else {
      x = e.nativeEvent.offsetX
      y = e.nativeEvent.offsetY
    }

    ctx.beginPath()
    ctx.moveTo(x, y)
    ctx.lineCap = "round"
    ctx.lineJoin = "round"
    ctx.strokeStyle = tool === "eraser" ? "white" : color
    ctx.lineWidth = lineWidth
  }

  const draw = (e: React.MouseEvent<HTMLCanvasElement> | React.TouchEvent<HTMLCanvasElement>) => {
    if (!isDrawing) return

    const canvas = canvasRef.current
    if (!canvas) return

    const ctx = canvas.getContext("2d")
    if (!ctx) return

    // Get coordinates
    let x, y
    if ("touches" in e) {
      const rect = canvas.getBoundingClientRect()
      x = e.touches[0].clientX - rect.left
      y = e.touches[0].clientY - rect.top
    } else {
      x = e.nativeEvent.offsetX
      y = e.nativeEvent.offsetY
    }

    ctx.lineTo(x, y)
    ctx.stroke()
  }

  const stopDrawing = () => {
    if (!isDrawing) return

    const canvas = canvasRef.current
    if (!canvas) return

    const ctx = canvas.getContext("2d")
    if (!ctx) return

    ctx.closePath()
    setIsDrawing(false)

    // Save state to history
    const currentState = ctx.getImageData(0, 0, canvas.width, canvas.height)

    // Remove any states after current index
    const newHistory = history.slice(0, historyIndex + 1)

    setHistory([...newHistory, currentState])
    setHistoryIndex(newHistory.length)
  }

  const clearCanvas = () => {
    const canvas = canvasRef.current
    if (!canvas) return

    const ctx = canvas.getContext("2d")
    if (!ctx) return

    ctx.fillStyle = "white"
    ctx.fillRect(0, 0, canvas.width, canvas.height)

    // Save cleared state to history
    const clearedState = ctx.getImageData(0, 0, canvas.width, canvas.height)

    setHistory([...history, clearedState])
    setHistoryIndex(history.length)
  }

  const saveDrawing = () => {
    const canvas = canvasRef.current
    if (!canvas) return

    // Create a temporary link
    const link = document.createElement("a")
    link.download = "drawing.png"
    link.href = canvas.toDataURL("image/png")
    link.click()
  }

  const undo = () => {
    if (historyIndex <= 0) return

    const canvas = canvasRef.current
    if (!canvas) return

    const ctx = canvas.getContext("2d")
    if (!ctx) return

    const newIndex = historyIndex - 1
    ctx.putImageData(history[newIndex], 0, 0)
    setHistoryIndex(newIndex)
  }

  const redo = () => {
    if (historyIndex >= history.length - 1) return

    const canvas = canvasRef.current
    if (!canvas) return

    const ctx = canvas.getContext("2d")
    if (!ctx) return

    const newIndex = historyIndex + 1
    ctx.putImageData(history[newIndex], 0, 0)
    setHistoryIndex(newIndex)
  }

  return (
    <div className="min-h-screen bg-slate-100 flex flex-col">
      {/* Header */}
      <header className="bg-white border-b border-slate-200 py-4 px-6 flex items-center justify-between">
        <div className="flex items-center gap-4">
          <Link href="/" className="text-slate-600 hover:text-slate-900">
            <Home className="h-5 w-5" />
          </Link>
          <h1 className="text-xl font-semibold text-slate-900 hidden md:block">Drawing Canvas</h1>
        </div>

        {exerciseInfo && (
          <div className="text-center">
            <Link
              href={`/ebook/${exerciseInfo.chapter}?page=${exerciseInfo.page}`}
              className="text-sm text-slate-600 hover:text-slate-900 flex items-center"
            >
              <ChevronLeft className="h-4 w-4 mr-1" /> Back to eBook
            </Link>
          </div>
        )}

        <div className="flex items-center gap-2">
          <Button onClick={saveDrawing} variant="outline" size="sm">
            <Save className="h-4 w-4 mr-2" /> Save
          </Button>

          {exerciseInfo && (
            <Sheet>
              <SheetTrigger asChild>
                <Button variant="outline" size="sm">
                  <PanelLeft className="h-4 w-4 mr-2" /> Instructions
                </Button>
              </SheetTrigger>
              <SheetContent side="left">
                <div className="py-4">
                  <h2 className="text-xl font-bold mb-4">Exercise Instructions</h2>
                  {exerciseDetails && (
                    <div className="prose">
                      <h3>{exerciseDetails.title}</h3>
                      <p>{exerciseDetails.exerciseText}</p>
                    </div>
                  )}
                </div>
              </SheetContent>
            </Sheet>
          )}
        </div>
      </header>

      {/* Toolbar */}
      <div className="bg-white border-b border-slate-200 py-2 px-6">
        <div className="flex flex-wrap items-center gap-4">
          <TooltipProvider>
            <Tooltip>
              <TooltipTrigger asChild>
                <Button
                  variant={tool === "pencil" ? "default" : "outline"}
                  size="icon"
                  onClick={() => setTool("pencil")}
                >
                  <Pencil className="h-5 w-5" />
                </Button>
              </TooltipTrigger>
              <TooltipContent>Pencil</TooltipContent>
            </Tooltip>
          </TooltipProvider>

          <TooltipProvider>
            <Tooltip>
              <TooltipTrigger asChild>
                <Button
                  variant={tool === "eraser" ? "default" : "outline"}
                  size="icon"
                  onClick={() => setTool("eraser")}
                >
                  <Eraser className="h-5 w-5" />
                </Button>
              </TooltipTrigger>
              <TooltipContent>Eraser</TooltipContent>
            </Tooltip>
          </TooltipProvider>

          <div className="h-8 w-px bg-slate-200 mx-2"></div>

          <div className="flex items-center gap-2">
            <label htmlFor="color-picker" className="sr-only">
              Color
            </label>
            <input
              id="color-picker"
              type="color"
              value={color}
              onChange={(e) => setColor(e.target.value)}
              className="w-8 h-8 rounded-md border border-slate-300 cursor-pointer"
            />
          </div>

          <div className="flex items-center gap-2 w-32">
            <span className="text-sm text-slate-500">Size:</span>
            <Slider value={[lineWidth]} min={1} max={20} step={1} onValueChange={(value) => setLineWidth(value[0])} />
          </div>

          <div className="h-8 w-px bg-slate-200 mx-2"></div>

          <TooltipProvider>
            <Tooltip>
              <TooltipTrigger asChild>
                <Button variant="outline" size="icon" onClick={undo} disabled={historyIndex <= 0}>
                  <Undo className="h-5 w-5" />
                </Button>
              </TooltipTrigger>
              <TooltipContent>Undo</TooltipContent>
            </Tooltip>
          </TooltipProvider>

          <TooltipProvider>
            <Tooltip>
              <TooltipTrigger asChild>
                <Button variant="outline" size="icon" onClick={redo} disabled={historyIndex >= history.length - 1}>
                  <Redo className="h-5 w-5" />
                </Button>
              </TooltipTrigger>
              <TooltipContent>Redo</TooltipContent>
            </Tooltip>
          </TooltipProvider>

          <TooltipProvider>
            <Tooltip>
              <TooltipTrigger asChild>
                <Button variant="outline" size="icon" onClick={clearCanvas}>
                  <Trash2 className="h-5 w-5" />
                </Button>
              </TooltipTrigger>
              <TooltipContent>Clear Canvas</TooltipContent>
            </Tooltip>
          </TooltipProvider>
        </div>
      </div>

      {/* Canvas */}
      <div className="flex-1 p-4 flex justify-center items-center">
        <div className="w-full max-w-4xl h-[70vh] bg-white rounded-lg shadow-lg overflow-hidden">
          <canvas
            ref={canvasRef}
            className="w-full h-full cursor-crosshair touch-none"
            onMouseDown={startDrawing}
            onMouseMove={draw}
            onMouseUp={stopDrawing}
            onMouseLeave={stopDrawing}
            onTouchStart={startDrawing}
            onTouchMove={draw}
            onTouchEnd={stopDrawing}
          />
        </div>
      </div>
    </div>
  )
}

