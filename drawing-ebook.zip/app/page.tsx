import Link from "next/link"
import { ChevronRight } from "lucide-react"
import { Button } from "@/components/ui/button"

export default function Home() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-50 to-slate-100">
      <div className="container mx-auto px-4 py-16">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-12">
            <h1 className="text-4xl md:text-6xl font-bold text-slate-900 mb-4">Master Drawing</h1>
            <p className="text-xl text-slate-600 mb-8">An interactive eBook to learn and practice drawing techniques</p>
            <div className="flex justify-center gap-4">
              <Button asChild size="lg" className="bg-slate-900 hover:bg-slate-800">
                <Link href="/ebook/1">
                  Start Reading <ChevronRight className="ml-2 h-4 w-4" />
                </Link>
              </Button>
              <Button asChild variant="outline" size="lg">
                <Link href="/canvas">Practice Now</Link>
              </Button>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mt-16">
            <div className="bg-white rounded-lg shadow-lg p-6 hover:shadow-xl transition-shadow">
              <h2 className="text-2xl font-bold text-slate-900 mb-3">Learn at Your Own Pace</h2>
              <p className="text-slate-600">
                Our interactive eBook provides step-by-step instructions with visual examples to help you master drawing
                fundamentals and advanced techniques.
              </p>
            </div>

            <div className="bg-white rounded-lg shadow-lg p-6 hover:shadow-xl transition-shadow">
              <h2 className="text-2xl font-bold text-slate-900 mb-3">Practice as You Learn</h2>
              <p className="text-slate-600">
                Each chapter includes interactive exercises where you can practice directly in your browser with our
                built-in drawing canvas.
              </p>
            </div>

            <div className="bg-white rounded-lg shadow-lg p-6 hover:shadow-xl transition-shadow">
              <h2 className="text-2xl font-bold text-slate-900 mb-3">Track Your Progress</h2>
              <p className="text-slate-600">
                Save your drawings and track your improvement over time with our progress tracking system.
              </p>
            </div>

            <div className="bg-white rounded-lg shadow-lg p-6 hover:shadow-xl transition-shadow">
              <h2 className="text-2xl font-bold text-slate-900 mb-3">Community Support</h2>
              <p className="text-slate-600">
                Share your work with other learners, get feedback, and participate in drawing challenges to improve your
                skills.
              </p>
            </div>
          </div>

          <div className="mt-16 text-center">
            <h2 className="text-3xl font-bold text-slate-900 mb-6">What You'll Learn</h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
              {["Basic Shapes", "Perspective", "Shading", "Human Anatomy", "Landscapes", "Digital Art"].map((topic) => (
                <div key={topic} className="bg-white rounded-lg p-4 shadow">
                  <p className="font-medium text-slate-800">{topic}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

