export const chapters = [
  {
    id: 1,
    title: "Getting Started with Drawing",
    content: [
      {
        title: "Introduction to Drawing",
        text: `
          <p>Welcome to your journey into the world of drawing! This chapter will introduce you to the fundamental concepts and tools you'll need to get started.</p>
          
          <p>Drawing is both an art and a skill. Like any skill, it can be learned and improved with practice. Don't worry if your first attempts don't match your expectations—every artist started somewhere!</p>
          
          <h3>What You'll Need</h3>
          <ul>
            <li>Paper (sketchbook recommended)</li>
            <li>Pencils (HB, 2B, 4B, 6B)</li>
            <li>Eraser</li>
            <li>Sharpener</li>
          </ul>
          
          <p>For digital drawing, you can use a tablet or even this web application's canvas to practice!</p>
          
          <p>In the following pages, we'll explore the basic elements of drawing and help you develop the foundational skills needed to express yourself through art.</p>
        `,
        hasExercise: false,
        exerciseText: "",
      },
      {
        title: "Basic Shapes and Forms",
        text: `
          <p>All drawings, no matter how complex, can be broken down into basic shapes and forms. Learning to see and draw these fundamental elements is the first step in developing your drawing skills.</p>
          
          <h3>The Five Basic Shapes</h3>
          <ul>
            <li><strong>Circle/Ellipse:</strong> The foundation for organic forms</li>
            <li><strong>Square/Rectangle:</strong> The basis for structural elements</li>
            <li><strong>Triangle:</strong> Creates dynamic and directional elements</li>
            <li><strong>Polygon:</strong> Combines aspects of triangles and squares</li>
            <li><strong>Irregular Shapes:</strong> Organic forms that don't fit the above categories</li>
          </ul>
          
          <p>Practice drawing these shapes freehand until you can create them with confidence. Don't worry about perfection—focus on consistency and control.</p>
          
          <h3>From 2D to 3D</h3>
          <p>Once you're comfortable with basic shapes, you can extend them into three-dimensional forms:</p>
          <ul>
            <li>Circle → Sphere</li>
            <li>Square → Cube</li>
            <li>Triangle → Pyramid or Cone</li>
            <li>Rectangle → Prism or Cylinder</li>
          </ul>
          
          <p>Try the exercise on the next page to practice drawing basic shapes and forms.</p>
        `,
        hasExercise: true,
        exerciseText:
          "Draw each of the five basic shapes (circle, square, triangle, polygon, and an irregular shape) three times. Then try to transform each into its 3D equivalent by adding appropriate shading.",
      },
      {
        title: "Lines and Mark Making",
        text: `
          <p>The quality of your lines can dramatically affect the feel and impact of your drawings. Different types of lines can convey different emotions and textures.</p>
          
          <h3>Types of Lines</h3>
          <ul>
            <li><strong>Straight lines:</strong> Convey structure, stability, and order</li>
            <li><strong>Curved lines:</strong> Suggest movement, grace, and organic forms</li>
            <li><strong>Zigzag lines:</strong> Create energy, excitement, or tension</li>
            <li><strong>Dotted/dashed lines:</strong> Indicate subtlety or suggestion</li>
          </ul>
          
          <h3>Line Weight</h3>
          <p>Varying the pressure on your pencil creates lines of different weights (thicknesses). Heavier lines can indicate:</p>
          <ul>
            <li>Elements closer to the viewer</li>
            <li>Stronger edges or boundaries</li>
            <li>Areas of focus or importance</li>
          </ul>
          
          <p>Lighter lines can suggest:</p>
          <ul>
            <li>Distance or recession</li>
            <li>Subtlety or delicacy</li>
            <li>Preliminary sketching or planning</li>
          </ul>
          
          <h3>Mark Making</h3>
          <p>Beyond lines, various marks can create texture and depth:</p>
          <ul>
            <li><strong>Hatching:</strong> Parallel lines that create tone</li>
            <li><strong>Cross-hatching:</strong> Overlapping lines that create darker tones</li>
            <li><strong>Stippling:</strong> Dots that create texture and tone</li>
            <li><strong>Scribbling:</strong> Loose, energetic marks that create movement</li>
          </ul>
        `,
        hasExercise: true,
        exerciseText:
          "Create a grid of 6 squares. In each square, practice a different line technique: straight lines, curved lines, zigzag lines, hatching, cross-hatching, and stippling. Try to create a gradient effect in each square, going from light to dark.",
      },
    ],
  },
  {
    id: 2,
    title: "Light and Shadow",
    content: [
      {
        title: "Understanding Light Sources",
        text: `
          <p>Light is perhaps the most important element in creating realistic drawings. Understanding how light interacts with objects is essential for creating depth and dimension in your artwork.</p>
          
          <h3>Properties of Light</h3>
          <ul>
            <li><strong>Direction:</strong> Where is the light coming from?</li>
            <li><strong>Intensity:</strong> How strong is the light?</li>
            <li><strong>Color:</strong> What color is the light? (Even "white" light has color temperature)</li>
            <li><strong>Quality:</strong> Is it hard (direct) or soft (diffused) light?</li>
          </ul>
          
          <h3>Single vs. Multiple Light Sources</h3>
          <p>When starting out, it's best to practice with a single, strong light source. This creates clear, defined shadows that are easier to understand and render. As you progress  This creates clear, defined shadows that are easier to understand and render. As you progress, you can experiment with multiple light sources, which create more complex and interesting shadow patterns.

<h3>The Five Elements of Shading</h3>
<p>When light hits an object, it creates five distinct tonal values:</p>
<ul>
  <li><strong>Highlight:</strong> The brightest area where light directly hits the object</li>
  <li><strong>Mid-tone:</strong> The natural color/value of the object in normal light</li>
  <li><strong>Core shadow:</strong> The darkest part of the shadow on the object itself</li>
  <li><strong>Reflected light:</strong> A lighter area within the shadow caused by light bouncing from nearby surfaces</li>
  <li><strong>Cast shadow:</strong> The shadow projected by the object onto other surfaces</li>
</ul>

<p>Understanding these elements will help you create more realistic and three-dimensional drawings.</p>
`,
        hasExercise: true,
        exerciseText:
          "Draw a simple sphere on your canvas. Add shading to show all five elements: highlight, mid-tone, core shadow, reflected light, and cast shadow. Imagine the light source coming from the upper left.",
      },
      {
        title: "Shading Techniques",
        text: `
<p>Now that you understand how light interacts with objects, let's explore different techniques for creating shading in your drawings.</p>

<h3>Basic Shading Methods</h3>
<ul>
  <li><strong>Hatching:</strong> Parallel lines drawn close together. The closer the lines, the darker the tone.</li>
  <li><strong>Cross-hatching:</strong> Overlapping sets of parallel lines. More layers create darker tones.</li>
  <li><strong>Stippling:</strong> Using dots to create tone. More dots = darker tone.</li>
  <li><strong>Blending:</strong> Smoothing tones with a blending tool or finger for a seamless gradient.</li>
  <li><strong>Scumbling:</strong> Circular, scribbling motions that create a textured look.</li>
</ul>

<h3>Creating Gradients</h3>
<p>Gradual transitions from light to dark are essential for creating realistic volume. Practice creating smooth gradients using each of the techniques above.</p>

<h3>Material Properties</h3>
<p>Different materials reflect light differently:</p>
<ul>
  <li><strong>Matte surfaces:</strong> Diffuse light evenly, creating soft shadows</li>
  <li><strong>Glossy surfaces:</strong> Create sharp highlights and reflections</li>
  <li><strong>Metallic surfaces:</strong> Reflect the environment and have high contrast</li>
  <li><strong>Transparent/translucent:</strong> Allow light to pass through, creating complex effects</li>
</ul>

<p>When shading, consider the material properties of your subject to create more realistic renderings.</p>
`,
        hasExercise: true,
        exerciseText:
          "Create four small squares on your canvas. In each square, draw the same simple object (like a cube) but use a different shading technique: hatching, cross-hatching, stippling, and blending.",
      },
      {
        title: "Value and Contrast",
        text: `
<p>Value refers to the lightness or darkness of a color or tone. Understanding value is crucial for creating depth and focus in your drawings.</p>

<h3>The Value Scale</h3>
<p>A standard value scale ranges from pure white to pure black, with various shades of gray in between. Most artists use a 9-step value scale:</p>
<ul>
  <li>1: White</li>
  <li>3: Light gray</li>
  <li>5: Middle gray</li>
  <li>7: Dark gray</li>
  <li>9: Black</li>
</ul>
<p>(With 2, 4, 6, and 8 representing the intermediate values)</p>

<h3>Contrast and Focus</h3>
<p>Areas of high contrast (where light and dark values meet) naturally draw the viewer's eye. You can use this principle to create focal points in your drawing.</p>

<h3>Value Mapping</h3>
<p>When drawing from observation, try to identify the different values in your subject and map them to your value scale. This helps simplify complex scenes into manageable tonal relationships.</p>

<h3>Squinting</h3>
<p>A useful technique for seeing values more clearly is to squint your eyes when looking at your subject. This reduces detail and helps you see the basic value structure more clearly.</p>
`,
        hasExercise: true,
        exerciseText:
          "Create a value scale on your canvas with 5 boxes, ranging from white to black. Then draw a simple still life composition (like a cup or fruit) focusing on accurately representing the values you observe.",
      },
    ],
  },
  {
    id: 3,
    title: "Perspective and Depth",
    content: [
      {
        title: "Introduction to Perspective",
        text: `
<p>Perspective is the art of creating the illusion of three-dimensional space on a two-dimensional surface. Understanding perspective is essential for creating realistic drawings with proper spatial relationships.</p>

<h3>Types of Perspective</h3>
<ul>
  <li><strong>Linear Perspective:</strong> Uses converging lines to create the illusion of depth</li>
  <li><strong>Atmospheric Perspective:</strong> Uses changes in color, contrast, and detail to suggest distance</li>
  <li><strong>Isometric Perspective:</strong> A form of parallel projection where lines don't converge</li>
</ul>

<h3>Linear Perspective Basics</h3>
<p>Linear perspective is based on the observation that parallel lines appear to converge as they recede into the distance, meeting at points called vanishing points on the horizon line.</p>

<h3>Key Elements of Linear Perspective</h3>
<ul>
  <li><strong>Horizon Line:</strong> Represents the viewer's eye level</li>
  <li><strong>Vanishing Points:</strong> Points where parallel lines appear to converge</li>
  <li><strong>Orthogonal Lines:</strong> Lines that recede toward vanishing points</li>
</ul>

<p>In the following pages, we'll explore different types of linear perspective in more detail.</p>
`,
        hasExercise: false,
        exerciseText: "",
      },
      {
        title: "One-Point Perspective",
        text: `
<p>One-point perspective is the simplest form of linear perspective. It's used when the viewer is looking straight at an object, with only one set of parallel lines receding into the distance.</p>

<h3>When to Use One-Point Perspective</h3>
<ul>
  <li>Drawing rooms or hallways viewed from the entrance</li>
  <li>Streets or railroad tracks viewed head-on</li>
  <li>Objects with a front-facing view where only the depth recedes</li>
</ul>

<h3>Key Elements</h3>
<ul>
  <li><strong>Horizon Line:</strong> Placed at eye level</li>
  <li><strong>Single Vanishing Point:</strong> Typically placed on the horizon line</li>
  <li><strong>Orthogonal Lines:</strong> All receding lines converge at the vanishing point</li>
  <li><strong>Transversal Lines:</strong> Horizontal and vertical lines remain parallel to the edges of your paper</li>
</ul>

<h3>Steps to Draw in One-Point Perspective</h3>
<ol>
  <li>Draw a horizon line across your paper</li>
  <li>Place a vanishing point on the horizon line</li>
  <li>Draw the front face of your object (e.g., a cube) using horizontal and vertical lines</li>
  <li>Connect the corners of the front face to the vanishing point to create receding lines</li>
  <li>Add depth by drawing back edges where appropriate</li>
</ol>
`,
        hasExercise: true,
        exerciseText:
          "Draw a simple room interior using one-point perspective. Include a floor, ceiling, side walls, and a few rectangular objects like windows, doors, or furniture. Place the vanishing point near the center of your canvas.",
      },
      {
        title: "Two-Point Perspective",
        text: `
<p>Two-point perspective is used when the viewer is looking at an object from an angle, with two sets of parallel lines receding toward different vanishing points.</p>

<h3>When to Use Two-Point Perspective</h3>
<ul>
  <li>Drawing buildings or objects viewed from a corner</li>
  <li>Street intersections</li>
  <li>Any object where you can see two sides simultaneously</li>
</ul>

<h3>Key Elements</h3>
<ul>
  <li><strong>Horizon Line:</strong> Placed at eye level</li>
  <li><strong>Two Vanishing Points:</strong> Placed on the horizon line, usually far apart</li>
  <li><strong>Orthogonal Lines:</strong> Receding lines converge at their respective vanishing points</li>
  <li><strong>Vertical Lines:</strong> Remain parallel to the edges of your paper</li>
</ul>

<h3>Steps to Draw in Two-Point Perspective</h3>
<ol>
  <li>Draw a horizon line across your paper</li>
  <li>Place two vanishing points on the horizon line, ideally far apart</li>
  <li>Draw a vertical line to represent the nearest edge of your object</li>
  <li>From the top and bottom of this vertical line, draw lines to each vanishing point</li>
  <li>Add vertical lines to create the back edges of your object</li>
  <li>Complete the object by connecting appropriate points</li>
</ol>
`,
        hasExercise: true,
        exerciseText:
          "Draw a simple city block with buildings using two-point perspective. Place two vanishing points on the horizon line and create at least three rectangular buildings of different heights.",
      },
    ],
  },
]

