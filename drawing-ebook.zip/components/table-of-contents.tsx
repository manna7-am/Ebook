import Link from "next/link"
import { chapters } from "@/lib/ebook-data"

interface TableOfContentsProps {
  currentChapter: number
}

export default function TableOfContents({ currentChapter }: TableOfContentsProps) {
  return (
    <div className="py-4">
      <h2 className="text-xl font-bold mb-6">Table of Contents</h2>
      <ul className="space-y-4">
        {chapters.map((chapter) => (
          <li key={chapter.id}>
            <div className="mb-2">
              <Link
                href={`/ebook/${chapter.id}`}
                className={`text-lg font-medium ${
                  chapter.id === currentChapter ? "text-slate-900 font-semibold" : "text-slate-600 hover:text-slate-900"
                }`}
              >
                Chapter {chapter.id}: {chapter.title}
              </Link>
            </div>

            <ul className="pl-6 space-y-1">
              {chapter.content.map((page, index) => (
                <li key={index}>
                  <Link
                    href={`/ebook/${chapter.id}?page=${index + 1}`}
                    className={`text-sm ${
                      chapter.id === currentChapter ? "text-slate-800" : "text-slate-500 hover:text-slate-700"
                    }`}
                  >
                    {page.title}
                  </Link>
                </li>
              ))}
            </ul>
          </li>
        ))}
      </ul>
    </div>
  )
}

